/**@<tokens.c>::**/

/**
	Grupo 06 
	integrantes: F�bio Vin�cius Luciano da Silva, Jo�o Victor Fleming, Alexandre dos Anjos Souza
**/

#include <tokens.h>

char *token[] = {
    "id",
    "decimal",
    "octal",
    "hexadecimal",
    "float",
    ":=",
    ">=",
    "<=",
    "<>",
};
