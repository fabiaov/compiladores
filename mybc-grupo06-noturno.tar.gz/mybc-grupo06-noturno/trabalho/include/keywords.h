/**@<keywords.h>::**/

/**
	Grupo 06 
	integrantes: F�bio Vin�cius Luciano da Silva, Jo�o Victor Fleming, Alexandre dos Anjos Souza
**/

/** Aqui estão definidos os tokens reservados(identificadores reservados) **/
enum {
		QUIT = 65536,
		EXIT,
		BYE,
};

int iskeyword(const char *name);
