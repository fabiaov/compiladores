/**@<tokens.h>::**/

/**
	Grupo 06 
	integrantes: F�bio Vin�cius Luciano da Silva, Jo�o Victor Fleming, Alexandre dos Anjos Souza
**/

enum {
	ID = 1024,
	DEC,
	OCTAL,
	HEXA,
	FLT,
	ASGN,
	GEQ,
	LEQ,
	NEQ,
};

extern char *token[];
