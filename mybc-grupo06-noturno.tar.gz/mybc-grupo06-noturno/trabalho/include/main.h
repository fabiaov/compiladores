/**@<main.h>::**/

/**
	Grupo 06 
	integrantes: F�bio Vin�cius Luciano da Silva, Jo�o Victor Fleming, Alexandre dos Anjos Souza
**/

extern FILE *source;
extern int lookahead;
void cmd(void);
void E(void);
int gettoken(FILE *);
